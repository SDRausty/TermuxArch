# genTermuxArch
genTermuxArch
